#include "ProductB.h"

const char* ProductB::GetName()
{
	return "ProductB";
}
// virtual int GetPrice()...
