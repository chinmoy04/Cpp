#include "ProductA.h"

const char* ProductA::GetName()
{
	return "ProductA";
}
// virtual int GetPrice()...
